@extends('admin.layouts.app')
@section('title','Application #'.$application->application_number)
@section('page-title','Application Review')
@section('bc','<a href="'.route('admin.applications.index').'">Applications</a> / #'.$application->application_number)
@section('content')

@php
$isPending = in_array($application->status, ['submitted','under_review','info_requested','on_hold']);
$badgeMap  = ['submitted'=>['#6366f1','#ede9fe'],'under_review'=>['#0891b2','#e0f2fe'],'info_requested'=>['#d97706','#fef3c7'],'on_hold'=>['#d97706','#fef3c7'],'approved'=>['#059669','#d1fae5'],'declined'=>['#dc2626','#fee2e2'],'disbursed'=>['#2563eb','#dbeafe']];
[$tc,$bc] = $badgeMap[$application->status] ?? ['#64748b','#f1f5f9'];
$a = $application->affordability;
$afford = app(\App\Services\Admin\ApplicationService::class)->checkAffordability($application);
@endphp

@foreach(['success'=>'ok','info'=>'i','error'=>'e'] as $type=>$cls)
@if(session($type))
<div class="alert a-{{ $cls }}" style="margin-bottom:18px"><i class="bi bi-{{ $cls==='ok'?'check-circle-fill':($cls==='e'?'x-circle-fill':'info-circle-fill') }}"></i> {{ session($type) }}</div>
@endif
@endforeach

{{-- TOP HEADER --}}
<div style="background:#fff;border:1px solid var(--border);border-radius:16px;padding:20px 24px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px">
  <div style="display:flex;align-items:center;gap:16px">
    <div style="width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,var(--p),var(--s));display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:22px;flex-shrink:0">
      {{ strtoupper(substr($application->applicant_name,0,1)) }}
    </div>
    <div>
      <div style="font-size:19px;font-weight:800;color:var(--dark)">{{ $application->applicant_name }}</div>
      <div style="font-size:13px;color:var(--muted);margin-top:2px">
        {{ $application->application_number }} &nbsp;·&nbsp; {{ $application->cell_number ?? '—' }}
        @if($application->loanProduct) &nbsp;·&nbsp; {{ $application->loanProduct->name }} @endif
      </div>
    </div>
  </div>
  <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
    <span style="background:{{ $bc }};color:{{ $tc }};font-size:13px;font-weight:700;padding:6px 16px;border-radius:20px">{{ ucfirst(str_replace('_',' ',$application->status)) }}</span>
    @if($isPending)
      <button onclick="openModal('aModal')" class="btn btn-ok btn-sm"><i class="bi bi-check-lg"></i> Approve</button>
      <button onclick="openModal('dModal')" class="btn btn-e btn-sm"><i class="bi bi-x-lg"></i> Decline</button>
      <button onclick="openModal('hModal')" class="btn btn-w btn-sm"><i class="bi bi-pause-fill"></i> Hold</button>
      <button onclick="openModal('iModal')" class="btn btn-o btn-sm"><i class="bi bi-question-circle"></i> Request Info</button>
      @if($application->status !== 'under_review')
        <form method="POST" action="{{ route('admin.applications.mark-under-review',$application) }}" style="display:inline">@csrf<button class="btn btn-i btn-sm"><i class="bi bi-eye"></i> Mark Under Review</button></form>
      @endif
    @endif
    @if(in_array($application->status,['declined','on_hold']))
      <form method="POST" action="{{ route('admin.applications.reinstate',$application) }}" style="display:inline">@csrf<button class="btn btn-o btn-sm"><i class="bi bi-arrow-counterclockwise"></i> Reinstate</button></form>
    @endif
    @if($application->loan)
      <a href="{{ route('admin.loans.show',$application->loan) }}" class="btn btn-p btn-sm"><i class="bi bi-bank"></i> View Loan</a>
    @endif
  </div>
</div>

{{-- QUICK STATS --}}
<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin-bottom:20px">
  @foreach([
    ['Requested','M '.number_format($application->requested_amount??0,0),'currency-dollar','#4f46e5'],
    ['Term',($application->requested_term??'—').' months','calendar3','#0891b2'],
    ['Risk Score',$application->risk_score??'—','graph-up','#f59e0b'],
    ['Submitted',$application->submitted_at?->format('d M Y')??'Draft','clock','#64748b'],
    ['Officer',$application->assignedOfficer?->name??'Unassigned','person-badge','#10b981'],
  ] as [$label,$val,$icon,$color])
  <div style="background:#fff;border:1px solid var(--border);border-radius:12px;padding:14px 16px;display:flex;align-items:center;gap:11px">
    <div style="width:36px;height:36px;border-radius:10px;background:{{ $color }}18;display:flex;align-items:center;justify-content:center;color:{{ $color }};font-size:16px;flex-shrink:0"><i class="bi bi-{{ $icon }}"></i></div>
    <div><div style="font-size:14px;font-weight:700;color:var(--dark)">{{ $val }}</div><div style="font-size:11px;color:var(--muted)">{{ $label }}</div></div>
  </div>
  @endforeach
</div>

{{-- MAIN LAYOUT --}}
<div style="display:grid;grid-template-columns:1fr 300px;gap:18px;align-items:start">
<div>

  {{-- TABS — NEW ORDER: Personal > Affordability > Loan Details > Documents > Notes > Schedule --}}
  <div class="tabs">
    <button class="tab active" data-tg="app" data-t="personal"  onclick="switchTab('app','personal')"><i class="bi bi-person"></i> Personal</button>
    <button class="tab"        data-tg="app" data-t="afford"    onclick="switchTab('app','afford')"><i class="bi bi-calculator"></i> Affordability</button>
    <button class="tab"        data-tg="app" data-t="loan"      onclick="switchTab('app','loan')"><i class="bi bi-bank"></i> Loan Details</button>
    <button class="tab"        data-tg="app" data-t="docs"      onclick="switchTab('app','docs')"><i class="bi bi-files"></i> Documents <span style="background:var(--bg);color:var(--muted);font-size:10px;padding:1px 6px;border-radius:10px;margin-left:2px">{{ $application->documents->count() }}</span></button>
    <button class="tab"        data-tg="app" data-t="notes"     onclick="switchTab('app','notes')"><i class="bi bi-chat-text"></i> Notes <span style="background:var(--bg);color:var(--muted);font-size:10px;padding:1px 6px;border-radius:10px;margin-left:2px">{{ $application->notes->count() }}</span></button>
    <button class="tab"        data-tg="app" data-t="schedule"  onclick="switchTab('app','schedule')"><i class="bi bi-table"></i> Schedule</button>
  </div>

  {{-- ── PERSONAL TAB ──────────────────────────────────────────── --}}
  <div class="tpanel active" data-pg="app" data-p="personal">
    <div class="card" style="margin-bottom:16px">
      <div class="card-hdr"><span class="card-title">Personal Information</span></div>
      <div class="card-body">
        <div class="info-grid">
          @foreach(['Title'=>$application->title,'First Name'=>$application->first_name,'Surname'=>$application->surname,'National ID'=>$application->national_id,'Date of Birth'=>$application->date_of_birth?->format('d M Y'),'Gender'=>ucfirst($application->gender??''),'Marital Status'=>ucfirst($application->marital_status??''),'Cell'=>$application->cell_number,'Email'=>$application->email??'—'] as $l=>$v)
          <div><div class="info-lbl">{{ $l }}</div><div class="info-val">{{ $v ?: '—' }}</div></div>
          @endforeach
        </div>
      </div>
    </div>

    @if($application->employment)
    <div class="card" style="margin-bottom:16px">
      <div class="card-hdr"><span class="card-title">Employment Details</span></div>
      <div class="card-body">
        <div class="info-grid">
          @foreach(['Employer'=>$application->employment->employer_name,'Type'=>$application->employment->employer_type,'Job Title'=>$application->employment->job_title,'Department'=>$application->employment->department,'Employee #'=>$application->employment->employment_number,'HR Contact'=>$application->employment->contact_number] as $l=>$v)
          <div><div class="info-lbl">{{ $l }}</div><div class="info-val">{{ $v ?: '—' }}</div></div>
          @endforeach
        </div>
      </div>
    </div>
    @endif

    @if($application->bankDetails)
    <div class="card">
      <div class="card-hdr"><span class="card-title">Bank Details</span></div>
      <div class="card-body">
        <div class="info-grid">
          @foreach(['Bank'=>$application->bankDetails->bank_name,'Account Holder'=>$application->bankDetails->account_holder_name,'Account #'=>'••••'.substr($application->bankDetails->account_number??'',-4),'Account Type'=>ucfirst($application->bankDetails->account_type??'')] as $l=>$v)
          <div><div class="info-lbl">{{ $l }}</div><div class="info-val">{{ $v ?: '—' }}</div></div>
          @endforeach
        </div>
      </div>
    </div>
    @endif
  </div>

  {{-- ── AFFORDABILITY TAB ─────────────────────────────────────── --}}
  <div class="tpanel" data-pg="app" data-p="afford">

    {{-- Pass/fail banner --}}
    @if($a)
      @if(!$afford['passes'])
      <div style="background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.3);border-radius:12px;padding:14px 18px;display:flex;align-items:flex-start;gap:12px;margin-bottom:16px">
        <i class="bi bi-exclamation-triangle-fill" style="color:#d97706;font-size:20px;flex-shrink:0;margin-top:1px"></i>
        <div><div style="font-weight:700;color:#92400e;font-size:13.5px;margin-bottom:4px">Affordability Warning</div><div style="font-size:13px;color:#78350f;line-height:1.6">{{ $afford['warning'] }}</div></div>
      </div>
      @else
      <div style="background:rgba(16,185,129,.08);border:1px solid rgba(16,185,129,.2);border-radius:12px;padding:12px 18px;display:flex;align-items:center;gap:10px;margin-bottom:16px">
        <i class="bi bi-check-circle-fill" style="color:#10b981;font-size:18px;flex-shrink:0"></i>
        <div style="font-size:13px;color:#065f46;font-weight:600">Affordable — Monthly M{{ number_format($afford['monthly'],2) }} within disposable income of M{{ number_format($afford['disposable_income'],2) }}</div>
      </div>
      @endif
    @endif

    <div class="card">
      <div class="card-hdr"><span class="card-title"><i class="bi bi-calculator" style="color:var(--p);margin-right:6px"></i>Affordability Assessment</span></div>
      <div class="card-body">
        @if($a)

        {{-- 3-column summary --}}
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-bottom:24px">
          <div style="background:#f0f4ff;border-radius:10px;padding:16px;text-align:center;border:1px solid var(--border)">
            <div style="font-size:11px;color:var(--muted);font-weight:600;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">Gross Salary</div>
            <div style="font-size:24px;font-weight:800;color:var(--p)">M{{ number_format($a->monthly_earnings??0,2) }}</div>
          </div>
          <div style="background:#fff7f0;border-radius:10px;padding:16px;text-align:center;border:1px solid #fde8d0">
            <div style="font-size:11px;color:var(--muted);font-weight:600;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">Total Deductions</div>
            @php $totalDed = ($a->tax_deduction??0)+($a->existing_loans_deduction??0)+($a->other_deductions??0); @endphp
            <div style="font-size:24px;font-weight:800;color:#ea580c">M{{ number_format($totalDed,2) }}</div>
          </div>
          <div style="background:#f0fdf4;border-radius:10px;padding:16px;text-align:center;border:1px solid #bbf7d0">
            <div style="font-size:11px;color:var(--muted);font-weight:600;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">Net Salary</div>
            <div style="font-size:24px;font-weight:800;color:#16a34a">M{{ number_format($a->net_salary??0,2) }}</div>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px">
          {{-- Income breakdown --}}
          <div>
            <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:10px">Income Breakdown</div>
            <div style="background:#f8fafc;border-radius:10px;padding:14px">
              @foreach(['Gross / Basic Salary'=>[$a->monthly_earnings,false],'Tax Deductions'=>[$a->tax_deduction,true],'Existing Loan Deductions'=>[$a->existing_loans_deduction,true],'Other Deductions'=>[$a->other_deductions,true]] as $l=>[$v,$isDed])
              <div style="display:flex;justify-content:space-between;padding:7px 0;font-size:12.5px;border-bottom:1px solid var(--border)">
                <span style="color:var(--muted)">{{ $l }}</span>
                <span style="font-weight:600;{{ $isDed?'color:#ef4444':'' }}">{{ $isDed?'– ':'' }}M{{ number_format($v??0,2) }}</span>
              </div>
              @endforeach
              <div style="display:flex;justify-content:space-between;padding:9px 0;font-size:13.5px;font-weight:800;color:#16a34a">
                <span>Net Salary</span><span>M{{ number_format($a->net_salary??0,2) }}</span>
              </div>
            </div>
          </div>

          {{-- Expenses breakdown --}}
          <div>
            <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:10px">Living Expenses</div>
            <div style="background:#f8fafc;border-radius:10px;padding:14px">
              @foreach(['Rent'=>$a->rent,'Groceries'=>$a->groceries,'Transport'=>$a->transport,'Utilities'=>$a->utilities,'Education'=>$a->education??0,'Communication'=>$a->communication??0,'Medical'=>$a->medical??0,'Other Loans'=>$a->other_loan_repayments??0,'Other'=>$a->other_expenses] as $l=>$v)
              @if(($v??0) > 0)
              <div style="display:flex;justify-content:space-between;padding:6px 0;font-size:12.5px;border-bottom:1px solid var(--border)">
                <span style="color:var(--muted)">{{ $l }}</span>
                <span style="font-weight:600;color:#ef4444">– M{{ number_format($v,2) }}</span>
              </div>
              @endif
              @endforeach
              <div style="display:flex;justify-content:space-between;padding:9px 0;font-size:13px;font-weight:700;color:#dc2626">
                <span>Total Expenses</span><span>M{{ number_format($a->total_living_expenses??0,2) }}</span>
              </div>
            </div>
          </div>
        </div>

        {{-- Disposable income result --}}
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:16px">
          <div style="background:{{ ($a->disposable_income??0)>0?'rgba(16,185,129,.08)':'rgba(239,68,68,.06)' }};border-radius:12px;padding:18px;text-align:center;border:1px solid {{ ($a->disposable_income??0)>0?'rgba(16,185,129,.2)':'rgba(239,68,68,.2)' }}">
            <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">Disposable Income</div>
            <div style="font-size:28px;font-weight:800;color:{{ ($a->disposable_income??0)>0?'#10b981':'#ef4444' }}">M{{ number_format($a->disposable_income??0,2) }}</div>
            <div style="font-size:12px;color:var(--muted);margin-top:4px">{{ ($a->disposable_income??0)>0?'✓ Passes':'✗ Fails' }}</div>
          </div>
          @if($afford['monthly']>0)
          <div style="background:#f8fafc;border-radius:12px;padding:18px;text-align:center;border:1px solid var(--border)">
            <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">Monthly Instalment vs Disposable</div>
            <div style="font-size:22px;font-weight:800;color:var(--p)">M{{ number_format($afford['monthly'],2) }}</div>
            <div style="font-size:12px;margin-top:4px"><span class="badge {{ $afford['passes']?'bok':'be' }}">{{ $afford['passes']?'Affordable':'Not Affordable' }}</span></div>
          </div>
          @endif
        </div>

        @else
        <div style="text-align:center;padding:50px;color:var(--muted)">
          <i class="bi bi-calculator" style="font-size:44px;opacity:.25;display:block;margin-bottom:12px"></i>
          <div style="font-weight:600">No affordability data</div>
          <div style="font-size:12px;margin-top:4px">Borrower has not completed the income section</div>
        </div>
        @endif
      </div>
    </div>
  </div>

  {{-- ── LOAN DETAILS TAB ──────────────────────────────────────── --}}
  <div class="tpanel" data-pg="app" data-p="loan">

    {{-- Inline affordability warning --}}
    @if($a && !$afford['passes'])
    <div style="background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.3);border-radius:12px;padding:12px 16px;margin-bottom:14px;display:flex;align-items:center;gap:10px">
      <i class="bi bi-exclamation-triangle-fill" style="color:#d97706"></i>
      <div style="font-size:13px;color:#92400e">{{ $afford['warning'] }}</div>
    </div>
    @endif

    <div class="card" style="margin-bottom:16px">
      <div class="card-hdr">
        <span class="card-title">Requested Loan Terms</span>
        @if($isPending)<button onclick="openModal('ovModal')" class="btn btn-sm btn-o"><i class="bi bi-pencil"></i> Override</button>@endif
      </div>
      <div class="card-body">
        <div class="info-grid">
          @foreach(['Product'=>$application->loanProduct?->name,'Amount'=>'M '.number_format($application->requested_amount??0,2),'Term'=>($application->requested_term??'—').' months','Purpose'=>$application->loan_purpose??'—','Payout'=>ucfirst(str_replace('_',' ',$application->payout_method??'')),'Collection'=>ucfirst(str_replace('_',' ',$application->collection_method??''))] as $l=>$v)
          <div><div class="info-lbl">{{ $l }}</div><div class="info-val">{{ $v ?: '—' }}</div></div>
          @endforeach
        </div>
      </div>
    </div>

    @if($application->approved_amount)
    <div style="background:linear-gradient(135deg,rgba(16,185,129,.07),rgba(5,150,105,.04));border:1px solid rgba(16,185,129,.25);border-radius:14px;padding:20px;margin-bottom:16px">
      <div style="font-weight:700;color:#065f46;margin-bottom:14px;display:flex;align-items:center;gap:7px"><i class="bi bi-check-circle-fill" style="color:#10b981"></i> Approved Terms</div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px;text-align:center">
        <div><div style="font-size:11px;color:#065f46;font-weight:600;text-transform:uppercase">Amount</div><div style="font-size:22px;font-weight:800;color:#059669">M{{ number_format($application->approved_amount,0) }}</div></div>
        <div><div style="font-size:11px;color:#065f46;font-weight:600;text-transform:uppercase">Term</div><div style="font-size:22px;font-weight:800;color:#059669">{{ $application->approved_term }}mo</div></div>
        <div><div style="font-size:11px;color:#065f46;font-weight:600;text-transform:uppercase">Rate</div><div style="font-size:22px;font-weight:800;color:#059669">{{ $application->approved_interest_rate }}%</div></div>
        <div><div style="font-size:11px;color:#065f46;font-weight:600;text-transform:uppercase">Disburse</div><div style="font-size:16px;font-weight:700;color:#059669;margin-top:4px">{{ $application->disbursement_date?->format('d M Y') }}</div></div>
      </div>
    </div>
    @endif

    @if($isPending)
    <div class="card">
      <div class="card-hdr"><span class="card-title">Risk Assessment</span></div>
      <div class="card-body">
        <form method="POST" action="{{ route('admin.applications.set-risk-score',$application) }}" style="display:flex;gap:10px;align-items:flex-end">@csrf
          <div class="fg" style="margin-bottom:0;flex:1"><label class="fl">Risk Score (0–1000)</label><input type="number" name="risk_score" class="fc" min="0" max="1000" value="{{ $application->risk_score }}" placeholder="e.g. 720"></div>
          <button type="submit" class="btn btn-p">Update</button>
        </form>
        @if($application->risk_score)
        @php $rs=$application->risk_score;$rp=min(100,$rs/10);$rc=$rs>=700?'#10b981':($rs>=500?'#f59e0b':'#ef4444');$rl=$rs>=700?'Low Risk':($rs>=500?'Moderate Risk':'High Risk'); @endphp
        <div style="margin-top:14px">
          <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:5px"><span style="color:var(--muted)">Score: <strong style="color:{{ $rc }}">{{ $rs }}</strong></span><span style="color:{{ $rc }};font-weight:600">{{ $rl }}</span></div>
          <div style="height:8px;background:var(--bg);border-radius:99px;overflow:hidden"><div style="height:100%;width:{{ $rp }}%;background:{{ $rc }};border-radius:99px;transition:width .5s"></div></div>
        </div>
        @endif
      </div>
    </div>
    @endif
  </div>

  {{-- ── DOCUMENTS TAB ─────────────────────────────────────────── --}}
  <div class="tpanel" data-pg="app" data-p="docs">

    {{-- Upload new document (admin can add docs) --}}
    <div class="card" style="margin-bottom:16px">
      <div class="card-hdr"><span class="card-title"><i class="bi bi-upload" style="color:var(--p);margin-right:6px"></i>Upload Document</span></div>
      <div class="card-body">
        <form method="POST" action="{{ route('admin.applications.documents.upload', $application) }}" enctype="multipart/form-data">
          @csrf
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;align-items:end">
            <div class="fg" style="margin-bottom:0">
              <label class="fl">Document Type *</label>
              <select name="type" class="fc" required>
                <option value="">— Select Type —</option>
                @foreach(['national_id'=>'National ID','payslip'=>'Payslip','bank_statement'=>'Bank Statement','photo'=>'Passport Photo','employment_letter'=>'Employment Letter','other'=>'Other'] as $v=>$l)
                <option value="{{ $v }}">{{ $l }}</option>
                @endforeach
              </select>
            </div>
            <div class="fg" style="margin-bottom:0">
              <label class="fl">File * <span style="font-weight:400;font-size:11px;color:var(--muted)">(PDF/JPG/PNG max 5MB)</span></label>
              <input type="file" name="file" class="fc" accept=".pdf,.jpg,.jpeg,.png" required style="padding:8px 10px">
            </div>
            <div>
              <button type="submit" class="btn btn-p" style="width:100%;justify-content:center"><i class="bi bi-upload"></i> Upload</button>
            </div>
          </div>
          <div class="fg" style="margin-top:12px;margin-bottom:0">
            <label class="fl">Notes (optional)</label>
            <input type="text" name="notes" class="fc" placeholder="e.g. Submitted by borrower in person">
          </div>
        </form>
      </div>
    </div>

    {{-- Documents list --}}
    <div class="card">
      <div class="card-hdr"><span class="card-title">Documents ({{ $application->documents->count() }})</span></div>
      <div class="card-body">
        @forelse($application->documents as $doc)
        <div style="display:flex;align-items:center;justify-content:space-between;padding:13px 16px;border:1px solid var(--border);border-radius:12px;margin-bottom:10px" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='transparent'">
          <div style="display:flex;align-items:center;gap:12px">
            <div style="width:42px;height:42px;background:#f1f5f9;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;color:#64748b">
              <i class="bi bi-file-earmark-{{ str_contains($doc->mime_type??'','pdf')?'pdf':'text' }}-fill"></i>
            </div>
            <div>
              <div style="font-weight:600;font-size:13px">{{ ucfirst(str_replace('_',' ',$doc->type)) }}</div>
              <div style="font-size:11.5px;color:var(--muted)">{{ $doc->original_name }} &nbsp;·&nbsp; {{ $doc->created_at->format('d M Y') }}</div>
              @if($doc->notes)<div style="font-size:11px;color:var(--muted);font-style:italic">{{ $doc->notes }}</div>@endif
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            <span class="badge {{ $doc->status==='verified'?'bok':($doc->status==='rejected'?'be':'bw') }}">
              <i class="bi bi-{{ $doc->status==='verified'?'check-circle':'clock' }}" style="font-size:10px"></i> {{ ucfirst($doc->status) }}
            </span>
            @if($doc->status==='pending')
            <form method="POST" action="{{ route('admin.applications.documents.verify',[$application,$doc]) }}" style="display:inline">@csrf<button class="btn btn-xs btn-ok" title="Verify"><i class="bi bi-check"></i></button></form>
            <form method="POST" action="{{ route('admin.applications.documents.reject',[$application,$doc]) }}" style="display:inline">@csrf<button class="btn btn-xs btn-e" title="Reject"><i class="bi bi-x"></i></button></form>
            @endif
            <a href="{{ route('admin.applications.documents.download',[$application,$doc]) }}" class="btn btn-xs btn-o"><i class="bi bi-download"></i></a>
          </div>
        </div>
        @empty
        <div style="text-align:center;padding:48px;color:var(--muted)"><i class="bi bi-file-earmark-x" style="font-size:44px;opacity:.25;display:block;margin-bottom:12px"></i><div style="font-weight:600">No documents uploaded</div></div>
        @endforelse
      </div>
    </div>
  </div>

  {{-- ── NOTES TAB ─────────────────────────────────────────────── --}}
  <div class="tpanel" data-pg="app" data-p="notes">
    <div class="card" style="margin-bottom:16px">
      <div class="card-hdr"><span class="card-title">Add Note</span></div>
      <div class="card-body">
        <form method="POST" action="{{ route('admin.applications.notes.store',$application) }}">@csrf
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
            <div class="fg" style="margin-bottom:0"><label class="fl">Type</label><select name="type" class="fc">@foreach(['general'=>'General','approval'=>'Approval','decision'=>'Decision','status'=>'Status Update','info_request'=>'Info Request','override'=>'Override'] as $v=>$l)<option value="{{ $v }}">{{ $l }}</option>@endforeach</select></div>
            <div class="fg" style="margin-bottom:0;display:flex;align-items:flex-end"><label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px;font-weight:600;padding-bottom:9px"><input type="checkbox" name="is_internal" value="1" checked style="width:16px;height:16px;accent-color:var(--p)"> Internal only</label></div>
          </div>
          <div class="fg" style="margin-bottom:12px"><label class="fl">Note *</label><textarea name="content" class="fc" rows="3" required placeholder="Add a note…"></textarea></div>
          <button type="submit" class="btn btn-p btn-sm"><i class="bi bi-plus-lg"></i> Add Note</button>
        </form>
      </div>
    </div>
    <div class="card">
      <div class="card-hdr"><span class="card-title">Notes History ({{ $application->notes->count() }})</span></div>
      <div class="card-body" style="padding-bottom:10px">
        @forelse($application->notes as $note)
        <div style="padding:14px 16px;border-left:3px solid {{ $note->is_internal?'#f59e0b':'#4f46e5' }};background:#f8fafc;border-radius:0 12px 12px 0;margin-bottom:10px">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px">
            <span style="font-size:11px;font-weight:700;color:{{ $note->is_internal?'#d97706':'var(--p)' }};text-transform:uppercase;background:{{ $note->is_internal?'rgba(245,158,11,.12)':'rgba(79,70,229,.08)' }};padding:2px 8px;border-radius:99px">{{ str_replace('_',' ',strtoupper($note->type)) }}@if($note->is_internal) · Internal @endif</span>
            <div style="display:flex;align-items:center;gap:8px">
              <span style="font-size:11.5px;color:var(--muted)">{{ $note->created_at->format('d M Y H:i') }} · {{ $note->createdBy?->name ?? '—' }}</span>
              <form method="POST" action="{{ route('admin.applications.notes.destroy',[$application,$note]) }}" style="display:inline">@csrf @method('DELETE')<button class="btn btn-xs" style="background:none;border:none;color:var(--muted);cursor:pointer;padding:2px 5px"><i class="bi bi-trash"></i></button></form>
            </div>
          </div>
          <div style="font-size:13px;color:#334155;line-height:1.6">{{ $note->content }}</div>
        </div>
        @empty
        <div style="text-align:center;padding:40px;color:var(--muted)"><i class="bi bi-chat-left-dots" style="font-size:40px;opacity:.25;display:block;margin-bottom:10px"></i><div>No notes yet</div></div>
        @endforelse
      </div>
    </div>
  </div>

  {{-- ── SCHEDULE TAB ──────────────────────────────────────────── --}}
  <div class="tpanel" data-pg="app" data-p="schedule">
    <div class="card">
      <div class="card-hdr"><span class="card-title">Repayment Schedule Preview</span></div>
      <div class="card-body">
        <div style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap">
          <div class="fg" style="margin-bottom:0"><label class="fl">Amount (M)</label><input type="number" id="schAmt" class="fc" style="width:150px" value="{{ $application->approved_amount ?? $application->requested_amount }}" step="0.01"></div>
          <div class="fg" style="margin-bottom:0"><label class="fl">Rate (%/mo)</label><input type="number" id="schRate" class="fc" style="width:130px" value="{{ $application->approved_interest_rate ?? $application->loanProduct?->interest_rate ?? 0 }}" step="0.01"></div>
          <div class="fg" style="margin-bottom:0"><label class="fl">Term (months)</label><input type="number" id="schTerm" class="fc" style="width:130px" value="{{ $application->approved_term ?? $application->requested_term }}"></div>
          <div style="display:flex;align-items:flex-end"><button onclick="previewSchedule()" class="btn btn-p"><i class="bi bi-table"></i> Generate</button></div>
        </div>
        <div id="scheduleResult" style="overflow-x:auto"></div>
      </div>
    </div>
  </div>

</div>

{{-- SIDEBAR --}}
<div>
  {{-- Timeline --}}
  <div class="card" style="margin-bottom:16px">
    <div class="card-hdr"><span class="card-title">Timeline</span></div>
    <div style="padding:16px">
      @foreach([['Submitted',$application->submitted_at,'send','#4f46e5'],['Reviewed',$application->reviewed_at,'eye','#0891b2'],['Decided',$application->decided_at,'check-circle','#10b981']] as [$label,$date,$icon,$color])
      <div style="display:flex;gap:12px;padding:8px 0;{{ !$loop->last?'border-bottom:1px solid var(--border)':'' }}">
        <div style="width:30px;height:30px;border-radius:50%;background:{{ $date?$color.'18':'var(--bg)' }};display:flex;align-items:center;justify-content:center;color:{{ $date?$color:'var(--muted)' }};font-size:13px;flex-shrink:0"><i class="bi bi-{{ $icon }}"></i></div>
        <div><div style="font-size:12.5px;font-weight:600;color:{{ $date?'var(--dark)':'var(--muted)' }}">{{ $label }}</div><div style="font-size:11.5px;color:var(--muted)">{{ $date?->format('d M Y H:i') ?? 'Pending' }}</div></div>
      </div>
      @endforeach
    </div>
  </div>

  {{-- Assign officer --}}
  @if($isPending)
  <div class="card" style="margin-bottom:16px">
    <div class="card-hdr"><span class="card-title">Assign Officer</span></div>
    <div class="card-body">
      <form method="POST" action="{{ route('admin.applications.assign-officer',$application) }}">@csrf
        <div class="fg" style="margin-bottom:10px"><select name="officer_id" class="fc"><option value="">— Select Officer —</option>@foreach($officers as $o)<option value="{{ $o->id }}" {{ $application->assigned_officer_id===$o->id?'selected':'' }}>{{ $o->name }}</option>@endforeach</select></div>
        <button type="submit" class="btn btn-p btn-sm" style="width:100%;justify-content:center"><i class="bi bi-person-check"></i> Assign</button>
      </form>
      @if($application->assignedOfficer)
      <form method="POST" action="{{ route('admin.applications.unassign-officer',$application) }}" style="margin-top:8px">@csrf<button class="btn btn-o btn-sm" style="width:100%;justify-content:center"><i class="bi bi-person-x"></i> Unassign</button></form>
      @endif
    </div>
  </div>
  @endif

  {{-- Next of Kin --}}
  @if($application->nextOfKin->count())
  <div class="card" style="margin-bottom:16px">
    <div class="card-hdr"><span class="card-title">Next of Kin</span></div>
    <div style="padding:14px 18px">
      @foreach($application->nextOfKin as $i=>$k)
      <div style="{{ $i>0?'margin-top:12px;padding-top:12px;border-top:1px solid var(--border)':'' }}">
        <div style="font-weight:700;font-size:13px">{{ $k->first_name }} {{ $k->last_name }}</div>
        <div style="font-size:12px;color:var(--muted)">{{ $k->relationship }} · {{ $k->contact_number }}</div>
      </div>
      @endforeach
    </div>
  </div>
  @endif
</div>
</div>

{{-- MODALS (unchanged) --}}
<div class="mo" id="aModal"><div class="mb" style="max-width:560px">
  <div class="mh"><span class="mt"><i class="bi bi-check-circle-fill" style="color:#10b981"></i> Approve & Create Loan</span><button class="mc" onclick="closeModal('aModal')">&times;</button></div>
  <form method="POST" action="{{ route('admin.applications.approve',$application) }}">@csrf
    <div class="mbody">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
        <div class="fg"><label class="fl">Approved Amount (M) *</label><input type="number" name="approved_amount" class="fc" value="{{ $application->requested_amount }}" step="0.01" min="1" required oninput="liveCalc()"></div>
        <div class="fg"><label class="fl">Term (months) *</label><input type="number" name="approved_term" class="fc" id="mTerm" value="{{ $application->requested_term }}" min="1" max="120" required oninput="liveCalc()"></div>
        <div class="fg"><label class="fl">Interest Rate (%/month) *</label><input type="number" name="interest_rate" class="fc" id="mRate" value="{{ $application->loanProduct?->interest_rate }}" step="0.01" min="0" required oninput="liveCalc()"></div>
        <div class="fg"><label class="fl">Disbursement Date *</label><input type="date" name="disbursement_date" class="fc" value="{{ now()->addDay()->format('Y-m-d') }}" required></div>
      </div>
      <div id="modalCalc" style="background:#f0fdf4;border:1px solid #d1fae5;border-radius:10px;padding:12px 14px;margin-bottom:6px;display:flex;gap:20px;flex-wrap:wrap">
        <div style="text-align:center"><div style="font-size:11px;color:#065f46;font-weight:600">MONTHLY</div><div style="font-size:18px;font-weight:800;color:#059669" id="mc-monthly">—</div></div>
        <div style="text-align:center"><div style="font-size:11px;color:#065f46;font-weight:600">TOTAL</div><div style="font-size:18px;font-weight:800;color:#059669" id="mc-total">—</div></div>
        <div style="text-align:center"><div style="font-size:11px;color:#065f46;font-weight:600">INTEREST</div><div style="font-size:18px;font-weight:800;color:#059669" id="mc-interest">—</div></div>
      </div>
      <div id="mc-afford" style="display:none;background:#fef3c7;border:1px solid #f59e0b;border-radius:8px;padding:8px 12px;font-size:12px;color:#92400e;margin-bottom:10px"></div>
      <div class="fg"><label class="fl">Approval Notes</label><textarea name="notes" class="fc" rows="2" placeholder="Optional notes…"></textarea></div>
    </div>
    <div class="mf"><button type="button" class="btn btn-o" onclick="closeModal('aModal')">Cancel</button><button type="submit" class="btn btn-ok"><i class="bi bi-check-lg"></i> Approve & Create Loan</button></div>
  </form>
</div></div>

<div class="mo" id="dModal"><div class="mb">
  <div class="mh"><span class="mt"><i class="bi bi-x-circle-fill" style="color:#ef4444"></i> Decline</span><button class="mc" onclick="closeModal('dModal')">&times;</button></div>
  <form method="POST" action="{{ route('admin.applications.decline',$application) }}">@csrf
    <div class="mbody"><div class="fg"><label class="fl">Decline Reason *</label><textarea name="reason" class="fc" rows="4" required></textarea></div></div>
    <div class="mf"><button type="button" class="btn btn-o" onclick="closeModal('dModal')">Cancel</button><button type="submit" class="btn btn-e"><i class="bi bi-x-lg"></i> Decline</button></div>
  </form>
</div></div>

<div class="mo" id="hModal"><div class="mb">
  <div class="mh"><span class="mt"><i class="bi bi-pause-fill" style="color:#f59e0b"></i> Place On Hold</span><button class="mc" onclick="closeModal('hModal')">&times;</button></div>
  <form method="POST" action="{{ route('admin.applications.hold',$application) }}">@csrf
    <div class="mbody"><div class="fg"><label class="fl">Reason *</label><textarea name="reason" class="fc" rows="3" required></textarea></div></div>
    <div class="mf"><button type="button" class="btn btn-o" onclick="closeModal('hModal')">Cancel</button><button type="submit" class="btn btn-w"><i class="bi bi-pause-fill"></i> Hold</button></div>
  </form>
</div></div>

<div class="mo" id="iModal"><div class="mb">
  <div class="mh"><span class="mt"><i class="bi bi-question-circle-fill" style="color:#4f46e5"></i> Request Information</span><button class="mc" onclick="closeModal('iModal')">&times;</button></div>
  <form method="POST" action="{{ route('admin.applications.request-info',$application) }}">@csrf
    <div class="mbody"><div class="fg"><label class="fl">Message to Borrower *</label><textarea name="message" class="fc" rows="4" required></textarea></div></div>
    <div class="mf"><button type="button" class="btn btn-o" onclick="closeModal('iModal')">Cancel</button><button type="submit" class="btn btn-p"><i class="bi bi-send"></i> Send</button></div>
  </form>
</div></div>

<div class="mo" id="ovModal"><div class="mb">
  <div class="mh"><span class="mt"><i class="bi bi-pencil-fill" style="color:#4f46e5"></i> Override Terms</span><button class="mc" onclick="closeModal('ovModal')">&times;</button></div>
  <form method="POST" action="{{ route('admin.applications.override-terms',$application) }}">@csrf
    <div class="mbody"><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px">
      <div class="fg"><label class="fl">Amount (M)</label><input type="number" name="loan_amount" class="fc" value="{{ $application->requested_amount }}" step="0.01"></div>
      <div class="fg"><label class="fl">Rate (%/mo)</label><input type="number" name="interest_rate" class="fc" value="{{ $application->loanProduct?->interest_rate }}" step="0.01"></div>
      <div class="fg"><label class="fl">Term (months)</label><input type="number" name="term_months" class="fc" value="{{ $application->requested_term }}"></div>
    </div></div>
    <div class="mf"><button type="button" class="btn btn-o" onclick="closeModal('ovModal')">Cancel</button><button type="submit" class="btn btn-p">Update Terms</button></div>
  </form>
</div></div>

<script>
const INITIATION_RATE = {{ $application->loanProduct?->initiation_fee_rate ?? 40 }} / 100;
const ADMIN_PER_MONTH = {{ $application->loanProduct?->admin_fee_fixed ?? 50 }};

function flatCalc(amount, ratePercent, term) {
  if (!amount || !term) return null;
  const rate=ratePercent/100, interest=amount*rate*term, initiation=amount*INITIATION_RATE, admin=ADMIN_PER_MONTH*term, total=amount+interest+initiation+admin, monthly=total/term;
  return {rate,interest,initiation,admin,total,monthly,principalPerMonth:amount/term,interestPerMonth:amount*rate,initiationPerMonth:initiation/term};
}

function liveCalc() {
  const amount=parseFloat(document.querySelector('[name=approved_amount]')?.value||0);
  const term=parseInt(document.getElementById('mTerm')?.value||0);
  const rate=parseFloat(document.getElementById('mRate')?.value||0);
  const c=flatCalc(amount,rate,term); if(!c) return;
  document.getElementById('mc-monthly').textContent='M '+c.monthly.toFixed(2);
  document.getElementById('mc-total').textContent='M '+c.total.toFixed(2);
  document.getElementById('mc-interest').textContent='M '+c.interest.toFixed(2);
  const netSal={{ (float)($application->affordability?->net_salary ?? 0) }};
  const warn=document.getElementById('mc-afford');
  if(warn&&netSal>0){const limit=netSal*0.3;if(c.monthly>limit){warn.style.display='block';warn.textContent='⚠ Monthly M'+c.monthly.toFixed(2)+' exceeds 30% limit M'+limit.toFixed(2);}else warn.style.display='none';}
}

function previewSchedule() {
  const amount=parseFloat(document.getElementById('schAmt').value||0);
  const rateP=parseFloat(document.getElementById('schRate').value||0);
  const term=parseInt(document.getElementById('schTerm').value||0);
  const c=flatCalc(amount,rateP,term); if(!c) return;
  let rows='',rem=amount;
  for(let i=1;i<=term;i++){const isLast=i===term;const prin=isLast?parseFloat(rem.toFixed(2)):parseFloat(c.principalPerMonth.toFixed(2));const init=parseFloat(c.initiationPerMonth.toFixed(2));const tot=parseFloat((prin+c.interestPerMonth+ADMIN_PER_MONTH+init).toFixed(2));rem=Math.max(0,rem-prin);rows+=`<tr style="font-size:12.5px"><td style="padding:8px 10px;border-bottom:1px solid var(--border)">${i}</td><td style="padding:8px 10px;border-bottom:1px solid var(--border);color:var(--p)">M ${prin.toFixed(2)}</td><td style="padding:8px 10px;border-bottom:1px solid var(--border);color:#f59e0b">M ${c.interestPerMonth.toFixed(2)}</td><td style="padding:8px 10px;border-bottom:1px solid var(--border);color:#8b5cf6">M ${init.toFixed(2)}</td><td style="padding:8px 10px;border-bottom:1px solid var(--border);color:#64748b">M ${ADMIN_PER_MONTH.toFixed(2)}</td><td style="padding:8px 10px;border-bottom:1px solid var(--border);font-weight:700">M ${tot.toFixed(2)}</td><td style="padding:8px 10px;border-bottom:1px solid var(--border)">M ${rem.toFixed(2)}</td></tr>`;}
  document.getElementById('scheduleResult').innerHTML=`<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px;text-align:center;font-size:13px"><div style="background:rgba(79,70,229,.06);border-radius:10px;padding:12px;border:1px solid rgba(79,70,229,.12)"><div style="font-size:11px;color:var(--muted)">Monthly</div><div style="font-size:19px;font-weight:800;color:var(--p)">M ${c.monthly.toFixed(2)}</div></div><div style="background:rgba(16,185,129,.06);border-radius:10px;padding:12px;border:1px solid rgba(16,185,129,.12)"><div style="font-size:11px;color:var(--muted)">Total Repay</div><div style="font-size:19px;font-weight:800;color:#10b981">M ${c.total.toFixed(2)}</div></div><div style="background:rgba(245,158,11,.06);border-radius:10px;padding:12px;border:1px solid rgba(245,158,11,.12)"><div style="font-size:11px;color:var(--muted)">Interest+Fees</div><div style="font-size:19px;font-weight:800;color:#f59e0b">M ${(c.interest+c.initiation+c.admin).toFixed(2)}</div></div><div style="background:rgba(100,116,139,.06);border-radius:10px;padding:12px;border:1px solid rgba(100,116,139,.12)"><div style="font-size:11px;color:var(--muted)">Cash to Client</div><div style="font-size:19px;font-weight:800;color:#475569">M ${amount.toFixed(2)}</div></div></div><table style="width:100%;border-collapse:collapse"><thead><tr style="background:#f8fafc;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:var(--muted)"><th style="padding:9px 10px;border-bottom:1px solid var(--border);text-align:left">#</th><th style="padding:9px 10px;border-bottom:1px solid var(--border);text-align:left">Principal</th><th style="padding:9px 10px;border-bottom:1px solid var(--border);text-align:left">Interest</th><th style="padding:9px 10px;border-bottom:1px solid var(--border);text-align:left">Initiation</th><th style="padding:9px 10px;border-bottom:1px solid var(--border);text-align:left">Admin</th><th style="padding:9px 10px;border-bottom:1px solid var(--border);text-align:left">Total</th><th style="padding:9px 10px;border-bottom:1px solid var(--border);text-align:left">Balance</th></tr></thead><tbody>${rows}</tbody></table>`;
}
</script>
@endsection
