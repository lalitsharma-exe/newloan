<?php
namespace App\Http\Controllers\Borrower;

use App\Http\Controllers\Controller;
use App\Models\{Payment, Loan, LoanInstallment};
use App\Services\CPayService;
use App\Services\Admin\LoanService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class PaymentController extends Controller
{
    public function __construct(
        private CPayService $cpay,
        private LoanService $loanService
    ) {}

    public function index()
    {
        $payments = Payment::where('user_id', auth('borrower')->id())
            ->with(['loan.loanProduct'])->latest()->paginate(15);
        return view('borrower.payments.index', compact('payments'));
    }

    public function show(Payment $payment)
    {
        abort_if($payment->user_id !== auth('borrower')->id(), 403);
        $payment->load(['loan.loanProduct']);
        return view('borrower.payments.show', compact('payment'));
    }

    public function showMakePayment()
    {
        $loans = Loan::where('user_id', auth('borrower')->id())
            ->whereIn('status', ['active','overdue'])
            ->with(['installments','loanProduct'])
            ->get();
        $cpayConfigured = $this->cpay->isConfigured();
        $cpayIsSandbox  = $this->cpay->isSandbox();
        return view('borrower.payments.make', compact('loans','cpayConfigured','cpayIsSandbox'));
    }

    /**
     * Initiate payment via CPay.
     *
     * Three real-world flows depending on method:
     *
     * 1. CARD
     *    → CPay returns a hosted payment page URL
     *    → We redirect the borrower's browser to that URL
     *    → Borrower enters card details on CPay's page
     *    → CPay redirects back to our callback URL when done
     *
     * 2. MOBILE MONEY (M-Pesa)
     *    → CPay sends a USSD push to the borrower's phone
     *    → Borrower sees "MyLoan requests M2,716. Enter PIN"
     *    → No browser redirect — we show a waiting page
     *    → Page polls our server every 5s
     *    → CPay sends webhook when confirmed → payment applied
     *
     * 3. CPAY WALLET
     *    → CPay sends push notification to CPay app or USSD
     *    → Same waiting page flow as mobile money
     */
    public function initiate(Request $request)
    {
        $request->validate([
            'loan_id' => 'required|exists:loans,id',
            'amount'  => 'required|numeric|min:1',
            'method'  => 'required|in:mobile_money,card,cpay_wallet,bank_transfer',
            'phone'   => 'nullable|string|max:30',
        ]);

        $loan   = Loan::where('user_id', auth('borrower')->id())->findOrFail($request->loan_id);
        $user   = auth('borrower')->user();
        $phone  = $request->phone ?? $user->phone;
        $amount = (float) $request->amount;
        $method = $request->method;

        // Create pending payment record (always — before any API call)
        $payment = Payment::create([
            'payment_reference' => 'PAY-' . strtoupper(\Illuminate\Support\Str::random(10)),
            'loan_id'           => $loan->id,
            'user_id'           => $user->id,
            'amount'            => $amount,
            'method'            => $method,
            'status'            => 'pending',
            'notes'             => 'Self-service payment via borrower portal',
        ]);

        // ─────────────────────────────────────────────────────────────────────
        // LIVE: CPay configured
        // ─────────────────────────────────────────────────────────────────────
        if ($this->cpay->isConfigured()) {
            $result = $this->cpay->initiateRepayment($payment, $phone, $method);

            if ($result['success']) {
                // Save CPay TXN ID so webhook can match it back
                $payment->update(['gateway_reference' => $result['cpay_txn_id']]);

                // ── CARD: Redirect to CPay hosted payment page ────────────────
                // CPay returns a paymentUrl / redirectUrl where the borrower
                // fills in their Visa/Mastercard details securely.
                if ($method === 'card' && !empty($result['redirect_url'])) {
                    return redirect()->away($result['redirect_url']);
                }

                // ── MOBILE MONEY / CPAY WALLET: Show waiting page ─────────────
                // CPay pushes USSD prompt to borrower's phone. No browser redirect.
                // Our waiting page polls GET /portal/payments/status?ref=PAY-xxx
                // every 5 seconds until CPay webhook fires.
                return view('borrower.payments.cpay-pending', [
                    'payment' => $payment,
                    'result'  => $result,
                    'method'  => $method,
                    'phone'   => $this->cpay->normalisePhone($phone),
                ]);
            }

            // CPay rejected the request
            $payment->update(['status' => 'failed', 'notes' => 'CPay error: ' . ($result['error'] ?? 'unknown')]);
            Log::error('CPay repayment initiation failed', [
                'ref'   => $payment->payment_reference,
                'error' => $result['error'] ?? '',
            ]);
            return redirect()->route('borrower.payments.make')
                ->with('error', 'Payment could not be started: ' . ($result['error'] ?? 'Please try again or contact support.'));
        }

        // ─────────────────────────────────────────────────────────────────────
        // DEMO MODE: No CPay credentials — auto-approve for testing
        // ─────────────────────────────────────────────────────────────────────
        $this->applyPaymentToLoan($payment);
        return redirect()->route('borrower.payments.callback.success', ['ref' => $payment->payment_reference]);
    }

    /**
     * CPay callback after card payment on hosted page (GET redirect from CPay).
     * Also used for mobile money after USSD confirmation.
     */
    public function callbackSuccess(Request $request)
    {
        $ref     = $request->input('ref') ?? $request->input('transactionId');
        $payment = Payment::where('payment_reference', $ref)
            ->where('user_id', auth('borrower')->id())
            ->first();

        if (!$payment) {
            return redirect()->route('borrower.payments.index')->with('error', 'Payment not found.');
        }

        // If still pending — poll CPay for final status
        if ($payment->status === 'pending' && $payment->gateway_reference && $this->cpay->isConfigured()) {
            $status = $this->cpay->queryPaymentStatus($payment->gateway_reference);
            if (($status['status'] ?? '') === 'PROCESSED') {
                $this->applyPaymentToLoan($payment);
            }
        }

        // Still pending (webhook hasn't fired or no gateway) — apply optimistically
        if ($payment->status === 'pending') {
            $this->applyPaymentToLoan($payment);
        }

        $payment->load(['loan.loanProduct']);
        return view('borrower.payments.callback-success', compact('payment'));
    }

    public function callbackCancel()
    {
        return redirect()->route('borrower.payments.make')->with('info', 'Payment cancelled.');
    }

    public function callbackFailed()
    {
        return view('borrower.payments.callback-failed');
    }

    /**
     * AJAX status poll — JS on the cpay-pending page calls this every 5 seconds
     * to check if CPay has confirmed the USSD/OTP payment yet.
     */
    public function checkStatus(Request $request)
    {
        $request->validate(['ref' => 'required|string']);
        $payment = Payment::where('payment_reference', $request->ref)
            ->where('user_id', auth('borrower')->id())
            ->first();

        if (!$payment) return response()->json(['status' => 'not_found'], 404);

        // Poll CPay for current status
        if ($payment->status === 'pending' && $payment->gateway_reference && $this->cpay->isConfigured()) {
            $result    = $this->cpay->queryPaymentStatus($payment->gateway_reference);
            $cpayStatus = $result['status'] ?? 'UNKNOWN';

            if ($cpayStatus === 'PROCESSED') {
                $this->applyPaymentToLoan($payment);
            } elseif (in_array($cpayStatus, ['DENIED','CANCELED','EXPIRED'])) {
                $payment->update(['status' => 'failed', 'notes' => "CPay: {$cpayStatus}"]);
            }
        }

        $payment->refresh();
        return response()->json([
            'status'       => $payment->status,
            'amount'       => 'M' . number_format($payment->amount, 2),
            'reference'    => $payment->payment_reference,
            'redirect_url' => $payment->status === 'verified'
                ? route('borrower.payments.callback.success', ['ref' => $payment->payment_reference])
                : null,
        ]);
    }

    public function receipt(Payment $payment)
    {
        abort_if($payment->user_id !== auth('borrower')->id(), 403);
        $payment->load(['loan.loanProduct']);
        return view('borrower.payments.receipt', compact('payment'));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Apply a verified payment to the loan installments
    // ─────────────────────────────────────────────────────────────────────────
    private function applyPaymentToLoan(Payment $payment): void
    {
        if ($payment->status === 'verified') return;

        $payment->update(['status' => 'verified', 'verified_at' => now()]);

        $loan = $payment->loan;
        if (!$loan) return;

        // Apply to installments oldest-first, in component allocation order
        $remaining    = (float) $payment->amount;
        $installments = $loan->installments()
            ->whereIn('status', ['pending','overdue','partial'])
            ->orderBy('due_date')
            ->get();

        foreach ($installments as $inst) {
            if ($remaining <= 0) break;
            $owed    = max(0, (float)$inst->total_amount - (float)$inst->paid_amount);
            if ($owed <= 0) continue;
            $apply   = min($remaining, $owed);
            $newPaid = round((float)$inst->paid_amount + $apply, 2);
            $newOut  = round(max(0, (float)$inst->total_amount - $newPaid), 2);
            $inst->update([
                'paid_amount'        => $newPaid,
                'outstanding_amount' => $newOut,
                'status'             => $newOut <= 0 ? 'paid' : 'partial',
                'paid_at'            => $newOut <= 0 ? now() : $inst->paid_at,
            ]);
            if (!$payment->installment_id) {
                $payment->update(['installment_id' => $inst->id]);
            }
            $remaining -= $apply;
        }

        $loan->decrement('outstanding_balance', (float)$payment->amount - $remaining);
        $loan->refresh();

        if ($loan->outstanding_balance <= 0 ||
            $loan->installments()->whereNotIn('status', ['paid','waived'])->count() === 0) {
            $loan->update(['status' => 'paid_off', 'last_payment_date' => now()]);
        }
    }
}
